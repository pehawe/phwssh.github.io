<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div id="page">
<div id="list-server">
<div style="clear:both;"></div>	
<div id="box">
<h2 class="title">Terms of Service</h2>
<p style="padding:10px 20px;text-aling;justify;">
<br>
- No DDOS <br>
- No Hacking<br>
- No Torrent<br>
- No Spam, etc.<br>
- Dont Repost or Reupload Account (We will delete account) <br>
- You are allowed using maximum 2 bitvise's<br>
- Use it wisely, So we can continue provide premium ssh account and proxy. <br>
<br>
<br>
All content on this website using our private server so we do not allow 
our content to be disseminated without permission from us to avoid 
misuse of the data that we provide.<br> If we found our content on a 
website that does not have permission from us, then we will report your 
website as the content theft to DMCA and Google. 
<br><br><br>
./<?php echo $_SERVER['HTTP_HOST'] ?><br><br>
<a href="http://www.dmca.com/Protection/Status.aspx?ID=745ec3cb-02dc-4f8a-aa02-daf2fec6ae30" title="DMCA"> <img src="<?php echo base_url().'assets/fastssh_style/css/DMCA_logo-std-btn225w.png' ?>" alt="DMCA.com"></a>
</p>
</div>


</div>

</div>
